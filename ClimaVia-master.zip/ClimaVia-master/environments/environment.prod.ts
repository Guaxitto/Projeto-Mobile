export const environment = {
    production: false,
    firebaseConfig: {
    apiKey: "AIzaSyBX2BtfIMLIChvUGu7A_mIe_V2IKCp-Nqg",
    authDomain: "climavia-7b803.firebaseapp.com",
    databaseURL: "https://climavia-7b803-default-rtdb.firebaseio.com",
    projectId: "climavia-7b803",
    storageBucket: "climavia-7b803.appspot.com",
    messagingSenderId: "321548348876",
    appId: "1:321548348876:web:a82403d3991ed245010169",
    measurementId: "G-78WL52629Q" 
  }};
  
