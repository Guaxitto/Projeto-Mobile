package com.climavia.com;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
